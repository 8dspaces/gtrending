package RunTest;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;

public class RunApiTest {
  @Test
  public void f() {
  }
  @AfterTest
  public void afterTest() {
  }

}
