package LoginAndToken;

import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeGroups;

public class GenerateToken {
	
	public static String token="";

	@BeforeGroups(groups="withToken")
	
	public static String generateToken() throws IOException,  JSONException  {
		
		String apiUrl = "/marketplace-login-service/marketplace/v1/user/generateToken?clientId=tokenTestClientId";
		//set api url
		String API = GetEnvironmentVar.setEnVarAndApiUrl(apiUrl);	

		// get expected result and actual result

		JSONObject json2 = GetResponseJSON.getResponseJSON("post", API, "");
		
		token=json2.getString("token");
		return token;
			
	}
	
}


