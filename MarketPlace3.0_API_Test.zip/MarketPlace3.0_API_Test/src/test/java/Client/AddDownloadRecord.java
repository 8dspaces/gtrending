package Client;

import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utils.CsvRead;
import Utils.GetCurrentTime;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;

public class AddDownloadRecord {
	
	@DataProvider(name = "data")
	public static Object[][] getPara(){
		String filePath = "./TestCase/Client/AddDownloadRecord.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;		
	}

	@Test(dataProvider = "data",groups="withToken")
	
	public void addDownloadRecord(String testCase,String method,String urlAPI,String getMethod,String getAPI,String expectedJSON) throws IOException, JSONException {
			
		urlAPI = GetEnvironmentVar.setEnVarAndApiUrl(urlAPI);	
		String sn = GetCurrentTime.getCurrentTime();
		String apiWithSN= urlAPI+sn;
		GetResponseJSON.getResponseJSONWithToken(method, apiWithSN);
				
		JSONObject json1 = new JSONObject(expectedJSON);
		
		String getAPIEn = GetEnvironmentVar.setEnVarAndApiUrl(getAPI);
		JSONObject json2 = GetResponseJSON.getResponseJSON(getMethod, getAPIEn+sn);
		
		org.testng.Reporter.log("[Test Case]:"+testCase);
		org.testng.Reporter.log("[API]:" + apiWithSN);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);
		
	}

}
