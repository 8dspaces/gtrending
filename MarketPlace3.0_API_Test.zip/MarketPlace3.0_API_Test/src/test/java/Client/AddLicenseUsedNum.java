package Client;

import org.testng.annotations.Test;
import Utils.CsvRead;
import Utils.GetCurrentTime;

import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;

public class AddLicenseUsedNum {
	
	
	@DataProvider(name = "data")
	public static Object[][] getPara(){
		String filePath = "./TestCase/Client/AddLicenseUsedNum.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;		
	}

	@Test(dataProvider = "data",groups={"withToken","license"})
	
	public void addLicenseUsedNum(String testCase,String method,String urlAPI,String expectedJSON,String requestBody) throws IOException, JSONException {
			
		urlAPI = GetEnvironmentVar.setEnVarAndApiUrl(urlAPI);		
		String apiWithSN= urlAPI+GetCurrentTime.getCurrentTime();
		JSONObject json1 = new JSONObject(expectedJSON);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(method, apiWithSN, requestBody);

		org.testng.Reporter.log("[Test Case]:"+testCase);
		org.testng.Reporter.log("[API]:" + apiWithSN);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.NON_EXTENSIBLE);
		

	}

}
		