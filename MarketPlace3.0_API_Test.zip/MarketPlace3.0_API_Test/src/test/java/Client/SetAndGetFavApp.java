package Client;

import org.testng.annotations.Test;
import Utils.CsvRead;
import Utils.GetCurrentTime;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;

public class SetAndGetFavApp {

	// get the test data from csv
	@DataProvider(name = "data")
	public static Object[][] getPara() {
		String filePath = "./TestCase/Client/SetAndGetFavApp.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;
	}

	@Test(dataProvider = "data",groups="withToken")
	public void setAndGetFavApp(String testCase, String setMethod, String setAPI, String getMethod, String getAPI, String expectedJSON, String setBody)
			throws Exception {

		setAPI = GetEnvironmentVar.setEnVarAndApiUrl(setAPI);
		String time  =GetCurrentTime.getCurrentTime();
		String setAPIsn= setAPI +time;
		JSONObject setFavAppRes = GetResponseJSON.getResponseJSONWithToken(setMethod, setAPIsn, setBody);				

		
		getAPI = GetEnvironmentVar.setEnVarAndApiUrl(getAPI);
		String getAPIsn= getAPI +time;
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(getMethod, getAPIsn);
		

		JSONObject json1 = new JSONObject(expectedJSON);
		
		org.testng.Reporter.log("[Test Case]:" + testCase);
		org.testng.Reporter.log("[API]:" + getAPIsn);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		
		
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);
		
		
	}

}
