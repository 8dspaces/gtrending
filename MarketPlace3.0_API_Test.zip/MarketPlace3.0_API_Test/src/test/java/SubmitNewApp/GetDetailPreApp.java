package SubmitNewApp;

import org.testng.annotations.Test;
import Utils.CsvRead;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;
import Utils.TearDown;
import Utils.SetUp_NewApp;

public class GetDetailPreApp {

	// get the test data from csv
	@DataProvider(name = "data")
	public static Object[][] getPara() {
		String filePath = "./TestCase/SubmitNewApp/GetDetailPreApp.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;
	}

	@Test(dataProvider = "data",groups="withToken")
	public void getDetailPreApp(String testCase, String setUpBody, String commitMethod,String commitAPI,String commitBody,String detailMethod, String detailAPI,String detailBody, String expectedJSON)
			throws Exception {

		//set up
		JSONObject jsonSetUp = SetUp_NewApp.setUp(setUpBody);
		String appId =jsonSetUp.getString("appId");
		
		//commit the app status
		String API_Post = GetEnvironmentVar.setEnVarAndApiUrl(commitAPI+appId);
		JSONObject json_post = GetResponseJSON.getResponseJSONWithToken(commitMethod, API_Post,commitBody);
				
		//run get detail
		String APIPost = GetEnvironmentVar.setEnVarAndApiUrl(detailAPI+appId);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(detailMethod, APIPost,detailBody);
		
		//get response 
		JSONObject json1 = new JSONObject(expectedJSON);

		//Tear Down
		TearDown.tearDown(appId);
		
		org.testng.Reporter.log("[Test Case]:" + testCase);
		org.testng.Reporter.log("[API]:" + APIPost);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		
		//assert	
		Assert.assertEquals(json_post.getInt("error"),0,"post failed");
		
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);		

	}
}
