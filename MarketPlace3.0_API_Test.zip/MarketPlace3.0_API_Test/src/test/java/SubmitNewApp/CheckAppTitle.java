package SubmitNewApp;

import org.testng.annotations.Test;
import Utils.CsvRead;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;
import Utils.TearDown;
import Utils.SetUp_NewApp;

public class CheckAppTitle {

	// get the test data from csv
	@DataProvider(name = "data")
	public static Object[][] getPara() {
		String filePath = "./TestCase/SubmitNewApp/CheckAppTitle.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;
	}

	@Test(dataProvider = "data",groups="withToken")
	public void checkAppTitle(String testCase, String setUpBody, String checkMethod, String checkAPI, String expectedJSON, String checkBody)
			throws Exception {

		//set up
		JSONObject jsonSetUp = SetUp_NewApp.setUp(setUpBody);
		String appId =jsonSetUp.getString("appId");
		
		//run case
		String API_checkTitle = GetEnvironmentVar.setEnVarAndApiUrl(checkAPI);
		
		JSONObject json1 = new JSONObject(expectedJSON);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(checkMethod, API_checkTitle,checkBody);
		
		//Tear Down
		TearDown.tearDown(appId);
		
		org.testng.Reporter.log("[Test Case]:" + testCase);
		org.testng.Reporter.log("[API]:" + API_checkTitle);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		//assert
		
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);		

	}

}
