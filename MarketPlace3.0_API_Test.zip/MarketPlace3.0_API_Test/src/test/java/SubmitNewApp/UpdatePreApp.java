package SubmitNewApp;

import org.testng.annotations.Test;
import Utils.CsvRead;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;
import Utils.TearDown;
import Utils.SetUp_NewApp;

public class UpdatePreApp {

	// get the test data from csv
	@DataProvider(name = "data")
	public static Object[][] getPara() {
		String filePath = "./TestCase/SubmitNewApp/UpdatePreApp.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;
	}

	@Test(dataProvider = "data",groups="withToken")
	public void updatePreApp(String testCase, String setUpBody, String methodPost, String APIpost,String postBody, String methodGet,String APIget,String expectedJSON)
			throws Exception {

		//set up
		JSONObject jsonSetUp = SetUp_NewApp.setUp(setUpBody);
		String appId =jsonSetUp.getString("appId");
		
		//run post case
		String APIPost = GetEnvironmentVar.setEnVarAndApiUrl(APIpost+appId);
		JSONObject jsonPost = GetResponseJSON.getResponseJSONWithToken(methodPost, APIPost,postBody);
		
		//get response and expected result
		JSONObject json1 = new JSONObject(expectedJSON);
		
		String APIGet = GetEnvironmentVar.setEnVarAndApiUrl(APIget+appId);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(methodGet, APIGet);
		
		//Tear Down
		TearDown.tearDown(appId);
		
		org.testng.Reporter.log("[Test Case]:" + testCase);
		org.testng.Reporter.log("[API]:" + APIPost);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		
		//assert
		Assert.assertEquals(jsonPost.getInt("error"),0,"post failed" );
		
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);		

	}

}
