package SubmitNewApp;

import org.testng.annotations.Test;
import Utils.CsvRead;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;
import Utils.TearDown;
import Utils.SetUp_NewApp;

public class CommitCheck {

	// get the test data from csv
	@DataProvider(name = "data")
	public static Object[][] getPara() {
		String filePath = "./TestCase/SubmitNewApp/CommitCheck.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;
	}

	@Test(dataProvider = "data",groups="withToken")
	public void commitCheck(String testCase, String setUpBody, String commitMethod,String commitAPI,String commitBody,String assertMethod, String assertAPI, String expectedJSON)
			throws Exception {

		//set up
		JSONObject jsonSetUp = SetUp_NewApp.setUp(setUpBody);
		String appId =jsonSetUp.getString("appId");
					
		//run commit check
		String commit_API = GetEnvironmentVar.setEnVarAndApiUrl(commitAPI+appId);
		JSONObject commitjson = GetResponseJSON.getResponseJSONWithToken(commitMethod, commit_API,commitBody);
		
		//get response 
		String assert_API = GetEnvironmentVar.setEnVarAndApiUrl(assertAPI);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(assertMethod, assert_API);
		
		//get expected result
		JSONObject json1 = new JSONObject(expectedJSON);

		//Tear Down
		TearDown.tearDown(appId);
		
		//log info to report
		org.testng.Reporter.log("[Test Case]:"+testCase);
		org.testng.Reporter.log("[API]:" + commit_API);
		org.testng.Reporter.log("[Response]:" + json2.toString());
		
		// assert	
		Assert.assertEquals(commitjson.getInt("error"),0,"commit failed");
				
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.LENIENT);		

	}
}
