package License;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utils.CsvRead;
import Utils.GetEnvironmentVar;
import Utils.GetResponseJSON;

public class GetMailInfo {
	
	
	@DataProvider(name = "data")
	public static Object[][] getPara(){
		String filePath = "./TestCase/License/GetMailInfo.csv";
		Object[][] array = CsvRead.readCSV(filePath);
		return array;		
	}

	@Test(groups={"withToken","license"},dataProvider = "data")
	
	public void getMailInfo(String testCase,String method,String urlAPI,String expectedJSON,String requestBody) throws IOException, JSONException {
			
		//set api url
		urlAPI = GetEnvironmentVar.setEnVarAndApiUrl(urlAPI);		

		// get expected result and actual result
		JSONObject json1 = new JSONObject(expectedJSON);
		JSONObject json2 = GetResponseJSON.getResponseJSONWithToken(method, urlAPI, requestBody);
		
		org.testng.Reporter.log("[Test Case]:"+testCase);
		org.testng.Reporter.log("[API]:" + urlAPI);	
		org.testng.Reporter.log("[Response]:" + json2.toString());
		JSONAssert.assertEquals(json1, json2, JSONCompareMode.NON_EXTENSIBLE);
		

	}

}
		
