package License;

import LoginAndToken.GenerateToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.json.JSONException;
import org.testng.annotations.BeforeGroups;
import Utils.GetEnvironmentVar;
import Utils.HttpPut;

public class PutLicense {
	

	@BeforeGroups(groups="license")
	
	public void putLicense() throws IOException, JSONException {
		
		File f = new File("./TestCase/License/PutLicenseBody.txt");
		BufferedReader reader = new BufferedReader(new FileReader(f));
		String requestBody ="",temp="";
		while((temp=reader.readLine())!=null){
			requestBody +=temp;
		}
		reader.close();
		
		String api="/marketplace-license-service/marketplace/v1/license?userId=1";
		String urlAPI = GetEnvironmentVar.setEnVarAndApiUrl(api);
		String header = GenerateToken.generateToken();
		HttpPut.putHttpHeader(urlAPI, requestBody, header);


	}

}
		

