package Utils;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource.Builder;

import LoginAndToken.GenerateToken;
import Utils.GetEnvironmentVar;

public class SetUp_NewApp {

	public static JSONObject setUp(String setUpBody) throws JSONException, IOException {
		
		//set put api
		String path = "/marketplace-package-service/marketplace/v1/preapp";
		String apiUrl = GetEnvironmentVar.setEnVarAndApiUrl(path);
		
		Client client = HttpClientCreate.createClient();
		Builder webSource = client.resource(apiUrl).header("token", GenerateToken.token);

		// JSONObject body = new JSONObject(requestBody);
		ClientResponse response = webSource.type("application/json").accept("application/json")
				.put(ClientResponse.class, setUpBody);

		Assert.assertEquals(response.getStatus(), 200, "API access failed");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		
		Assert.assertEquals(json.getInt("error"),0,"Put preApp failed");
		
		return json;
	}
}
