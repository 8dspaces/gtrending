package Utils;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource.Builder;

import LoginAndToken.GenerateToken;
import Utils.HttpClientCreate;
import Utils.GetEnvironmentVar;

public class TearDown {

	public static void tearDown(String appId)
			throws ClientHandlerException, UniformInterfaceException, JSONException, IOException {
		
		//Set delete api url
		String path = "/marketplace-package-service/marketplace/v1/preapp/delete?appId=" + appId;
		String apiUrl = GetEnvironmentVar.setEnVarAndApiUrl(path);

		// new client and set apiurl
		Client client = HttpClientCreate.createClient();
		Builder resource = client.resource(apiUrl).header("token", GenerateToken.token);

		// get response
		ClientResponse response = resource.accept("application/json").delete(ClientResponse.class);

		// assert if the access successfully
		Assert.assertEquals(response.getStatus(), 200, "API access failed");


		JSONObject json = new JSONObject(response.getEntity(String.class));
		Assert.assertEquals(json.getInt("error"), 0,"Tear Down failed !!");

	}

}
