package Utils;

import Utils.HttpGet;
import Utils.HttpPost;
import Utils.HttpPut;
import Utils.HttpDelete;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.UniformInterfaceException;

public class GetResponseJSON {
	
// please insert parameters like "method,apiUrl,requestbody"
	public static JSONObject getResponseJSON(String ...value)
			throws ClientHandlerException, UniformInterfaceException, JSONException {

		JSONObject json2 = null;
		
		String method, urlAPI ,requestBody="";
		method = value[0];
		urlAPI = value[1];
				
		if(value.length > 2){
			requestBody = value[2];
		}

		if (method.equals("get")) {
			json2 = HttpGet.getHttp(urlAPI);

		} else if (method.equals("post")) {

			json2 = HttpPost.postHttp(urlAPI, requestBody);
		} else if (method.equals("put")) {

			json2 = HttpPut.putHttp(urlAPI, requestBody);
		} else if (method.equals("delete")) {

			json2 = HttpDelete.deleteHttp(urlAPI);
		} else {

			System.out.println("API access method is wrong");
		}

		return json2;
	}
	
	public static JSONObject getResponseJSONWithToken(String ...value)
			throws ClientHandlerException, UniformInterfaceException, JSONException {

		JSONObject json2 = null;
		
		String method, urlAPI ,requestBody="";
		method = value[0];
		urlAPI = value[1];
				
		if(value.length > 2){
			requestBody = value[2];
		}

		if (method.equals("get")) {
			json2 = HttpGet.getHttpWithToken(urlAPI);

		} else if (method.equals("post")) {

			json2 = HttpPost.postHttpWithToken(urlAPI, requestBody);
		} else if (method.equals("put")) {

			json2 = HttpPut.putHttpWithToken(urlAPI, requestBody);
		} else if (method.equals("delete")) {

			json2 = HttpDelete.deleteHttpWithToken(urlAPI);
		} else {

			System.out.println("API access method is wrong");
		}

		return json2;
	}
}
