package Utils;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

import LoginAndToken.GenerateToken;
import Utils.HttpClientCreate;

public class HttpDelete {

	public static JSONObject deleteHttp(String apiUrl)
			throws ClientHandlerException, UniformInterfaceException, JSONException {

		// new client and set apiurl
		Client client = HttpClientCreate.createClient();
		WebResource resource = client.resource(apiUrl);

		// get response
		ClientResponse response = resource.accept("application/json").delete(ClientResponse.class);

		// assert if the access successfully
		Assert.assertEquals(response.getStatus(), 200, "[DELETE] API access failed");

		// get json to return
		JSONObject json = new JSONObject(response.getEntity(String.class));

		return json;

	}
	
	public static JSONObject deleteHttpWithToken(String apiUrl)
			throws ClientHandlerException, UniformInterfaceException, JSONException {

		// new client and set apiurl
		Client client = HttpClientCreate.createClient();
		Builder resource = client.resource(apiUrl).header("token", GenerateToken.token);

		// get response
		ClientResponse response = resource.accept("application/json").delete(ClientResponse.class);

		// assert if the access successfully
		Assert.assertEquals(response.getStatus(), 200, "[DELETE] API access failed");

		// get json to return
		JSONObject json = new JSONObject(response.getEntity(String.class));

		return json;

	}

}
