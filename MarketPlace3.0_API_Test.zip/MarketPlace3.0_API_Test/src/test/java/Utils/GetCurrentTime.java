package Utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetCurrentTime {
	
	public static String getCurrentTime(){
		
		Date now = new Date();
		SimpleDateFormat dateFormat =new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String date =dateFormat.format(now);
		return date;
	}
	

}
