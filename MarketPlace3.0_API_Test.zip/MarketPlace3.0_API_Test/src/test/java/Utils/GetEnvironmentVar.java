package Utils;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

//read environment var from local and combine with the api url
public class GetEnvironmentVar {

	public static String setEnVarAndApiUrl(String apiUrl) throws IOException {
		
		Properties pps = new Properties();
		
		InputStream in = new BufferedInputStream(new FileInputStream("./config.properties"));
		
		pps.load(in);
		
		String enVar = pps.getProperty("environmentValue");
		
		String API = enVar + apiUrl;
		return API;

	}

}
