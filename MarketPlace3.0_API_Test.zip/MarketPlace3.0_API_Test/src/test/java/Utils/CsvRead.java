package Utils;

import java.nio.charset.Charset;
import java.util.ArrayList;

import com.csvreader.CsvReader;

public class CsvRead {
	public static Object[][] readCSV(String filePath) {
		Object[][] object = new Object[0][0];

		try {
			ArrayList<String[]> list = new ArrayList<String[]>();

			CsvReader read = new CsvReader(filePath, ',', Charset.forName("UTF-8"));
			read.readHeaders();

			while (read.readRecord()) {

				list.add(read.getValues());
			}
			read.close();

			object = new Object[list.size()][list.get(0).length];
			for (int i = 0; i < list.size(); i++) {
				for (int j = 0; j < list.get(0).length; j++) {
					object[i][j] = list.get(i)[j];
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return object;
	}

}
