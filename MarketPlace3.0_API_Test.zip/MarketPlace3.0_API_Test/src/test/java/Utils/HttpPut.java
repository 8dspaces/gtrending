package Utils;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

import LoginAndToken.GenerateToken;

public class HttpPut {

	public static JSONObject putHttp(String urlAPI, String requestBody) throws JSONException {
		Client client = HttpClientCreate.createClient();
		WebResource webSource = client.resource(urlAPI);

		// JSONObject body = new JSONObject(requestBody);
		ClientResponse response = webSource.type("application/json").accept("application/json")
				.put(ClientResponse.class, requestBody);

		Assert.assertEquals(response.getStatus(), 200, "[put] API access failed");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		return json;
	}
	
	public static JSONObject putHttpWithToken(String urlAPI, String requestBody) throws JSONException {
		Client client = HttpClientCreate.createClient();
		Builder webSource = client.resource(urlAPI).header("token", GenerateToken.token);

		// JSONObject body = new JSONObject(requestBody);
		ClientResponse response = webSource.type("application/json").accept("application/json")
				.put(ClientResponse.class, requestBody);

		Assert.assertEquals(response.getStatus(), 200, "[put] API access failed");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		return json;
	}
	
	public static JSONObject putHttpHeader(String urlAPI, String requestBody, String header) throws JSONException {
		Client client = HttpClientCreate.createClient();
		Builder webSource = client.resource(urlAPI).header("token", header);

		// JSONObject body = new JSONObject(requestBody);
		ClientResponse response = webSource.type("application/json").accept("application/json")
				.put(ClientResponse.class, requestBody);

		Assert.assertEquals(response.getStatus(), 200, "[put] API access failed");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		return json;
	}
	
}
