package Utils;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

import LoginAndToken.GenerateToken;

public class HttpPost {
	public static JSONObject postHttp(String urlAPI, String requestBody) throws JSONException {

		Client client = HttpClientCreate.createClient();
		WebResource webResource = client.resource(urlAPI);

		ClientResponse response = webResource.type("application/json").accept("application/json")
				.post(ClientResponse.class, requestBody);

		Assert.assertEquals(response.getStatus(), 200, " [POST] API access fail");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		return json;

	}
	
	public static JSONObject postHttpWithToken(String urlAPI, String requestBody) throws JSONException {

		Client client = HttpClientCreate.createClient();
		Builder webResource = client.resource(urlAPI).header("token", GenerateToken.token);

		ClientResponse response = webResource.type("application/json").accept("application/json")
				.post(ClientResponse.class, requestBody);

		Assert.assertEquals(response.getStatus(), 200, " [POST] API access fail");

		JSONObject json = new JSONObject(response.getEntity(String.class));
		return json;

	}
}
